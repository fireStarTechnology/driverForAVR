/*
 * myEmConfig.h
 *
 * Created: 17-03-2018 13:17:39
 *  Author: maaply
 */ 


#ifndef MYEMCONFIG_H_
#define MYEMCONFIG_H_


#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

#include "sam.h"


#ifndef ON
#define ON (1)
#endif

#ifndef SET
#define SET (1)
#endif

#ifndef TRUE
#define TRUE (1)
#endif

#ifndef OFF
#define OFF (0)
#endif

#ifndef CLEAR
#define CLEAR (0)
#endif

#ifndef FALSE
#define FALSE (0)
#endif



#endif /* MYEMCONFIG_H_ */